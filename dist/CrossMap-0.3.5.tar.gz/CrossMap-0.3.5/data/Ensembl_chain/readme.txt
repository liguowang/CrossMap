These chain files were downloaded from: ftp://ftp.ensembl.org/pub/assembly_mapping/
