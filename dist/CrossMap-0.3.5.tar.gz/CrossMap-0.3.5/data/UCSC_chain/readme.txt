The chain format describes a pairwise alignment between two genomes.

Detailed description for chain format: https://genome.ucsc.edu/goldenPath/help/chain.html

Human hg38 chain files: http://hgdownload.soe.ucsc.edu/goldenPath/hg38/liftOver/

Human hg19 chain files: http://hgdownload.soe.ucsc.edu/goldenPath/hg19/liftOver/

Human hg18 chain files: http://hgdownload.soe.ucsc.edu/goldenPath/hg18/liftOver/

Other species: http://hgdownload.soe.ucsc.edu/downloads.html#liftover
