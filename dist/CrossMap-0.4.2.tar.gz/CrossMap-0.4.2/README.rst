Installation
==================

Use pip to install CrossMap
-----------------------------

::

 pip3 install git+https://github.com/liguowang/CrossMap.git
 
 or 
 
 pip3 install CrossMap	#Install CrossMap supporting Python3


Documentation
=============

https://crossmap.readthedocs.io/en/latest/ 

